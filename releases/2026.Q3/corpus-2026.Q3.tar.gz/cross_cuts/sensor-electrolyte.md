---
title: sensor-electrolyte
parent: Cross-cuts
layout: default
---

# Cross-cut: `sensor-electrolyte`

Axis: **sensors**

**4 corpus entries disclose this tag.**

Earliest disclosure: 2005-07-22

Listed in chronological order. Each entry's `prior_art_notes` and
`disclosure_citation` constitute the citeable prior art material.

---

## The Island — 24-hour ambient health monitoring with biochemical smart toilet (2005-07-22)

- **id**: `the-island-continuous-health-monitoring`
- **corpus**: fictional
- **form factor**: other
- **creator**: Michael Bay / DreamWorks
- **disclosure**: The Island (DreamWorks / Warner Bros.), released July 22, 2005; residents are told their health is monitored 24 hours a day, with proximity/contact sensors throughout the facility and a lavatory that analyses urine in real time and reports dietary findings ('there's too much sodium in your diet').
- **ip status**: fictional
- **sensors**: sensor-electrolyte
- **prior art notes**: Discloses (a) pervasive, continuous, ambient monitoring of residents' physiological state and (b) a lavatory that performs real-time urinalysis (electrolytes / sodium) and returns dietary feedback. Relevant to smart-toilet / in-fixture urinalysis claims combining 'a toilet fixture', 'a sensor analysing excreted fluid', and 'a determination of a dietary/physiological parameter' (the modern smart-toilet patent space), and to pervasive ambient-health-monitoring claims. § 103 motivation that the biochemical smart toilet was an articulated objective by 2005.

## Bandodkar & Wang (2014) — 'Non-invasive wearable electrochemical sensors: a review' (2014-07)

- **id**: `bandodkar-wang-2014-wearable-electrochemical-sensors-review`
- **corpus**: academic
- **form factor**: other
- **creator**: Amay J. Bandodkar / Joseph Wang (UC San Diego)
- **disclosure**: Bandodkar AJ, Wang J. 'Non-invasive wearable electrochemical sensors: a review.' Trends in Biotechnology 2014;32(7):363-371.
- **ip status**: public-domain
- **sensors**: sensor-lactate, sensor-electrolyte, sensor-ph, sensor-glucose-cgm, sensor-alcohol-transdermal, sensor-uric-acid, sensor-cortisol
- **algorithms**: algo-electrolyte-trend, algo-hydration-status
- **prior art notes**: Surveys, as of 2014, wearable non-invasive electrochemical biosensors across body fluids and form factors — temporary-tattoo electrodes on the skin (sweat lactate, Na+, ammonium, pH), textile-integrated sensors, mouthguard (saliva) sensors, contact-lens (tear glucose) sensors, and the transdermal/interstitial route — including the sampling, transduction, and on-body electronics issues. Prior art for wearable-electrochemical-sensing claims reciting any of the analyte/form-factor combinations collected here; the approaches were published by 2014. General anchor for the electrochemical wearable cross-cuts.

## Gao et al. (Javey group) (2016) — fully integrated wearable sensor array for multiplexed in-situ perspiration analysis (2016-01-28)

- **id**: `gao-javey-2016-wearable-sweat-sensor-array`
- **corpus**: academic
- **form factor**: headband
- **creator**: Wei Gao et al. / Ali Javey group (UC Berkeley)
- **disclosure**: Gao W, Emaminejad S, Nyein HYY, Challa S, Chen K, Peck A, et al. (Javey A). 'Fully integrated wearable sensor arrays for multiplexed in situ perspiration analysis.' Nature 2016;529(7587):509-514.
- **ip status**: public-domain
- **sensors**: sensor-lactate, sensor-glucose-cgm, sensor-electrolyte, sensor-ph, sensor-skin-temperature, sensor-microfluidic-sweat-collection
- **algorithms**: algo-electrolyte-trend, algo-hydration-status
- **prior art notes**: Discloses a fully integrated wearable (wristband / headband) with an array of electrochemical sensors measuring multiple sweat analytes simultaneously (glucose, lactate, Na+, K+) plus skin temperature for real-time signal compensation, with on-board signal conditioning, microcontroller, and wireless transmission to a phone — i.e. a complete in-situ sweat biochemistry monitor. Any wearable claim reciting 'a band-form device with an array of two or more electrochemical sweat-analyte sensors plus a temperature sensor for compensation, with integrated electronics and wireless output' reads on Gao/Javey 2016. Anchor for the sweat-electrochemical-sensing cross-cuts on the real side; [[bandodkar-wang-2014-wearable-electrochemical-sensors-review]] is the contemporaneous review.

## Koh et al. (Rogers group) (2016) — soft wearable microfluidic device for sweat capture, storage, and colorimetric sensing (2016-11-23)

- **id**: `koh-rogers-2016-soft-microfluidic-sweat-device`
- **corpus**: academic
- **form factor**: patch
- **creator**: Ahyeon Koh et al. / John A. Rogers group (Northwestern)
- **disclosure**: Koh A, Kang D, Xue Y, Lee S, Pielak RM, Kim J, et al. (Rogers JA). 'A soft, wearable microfluidic device for the capture, storage, and colorimetric sensing of sweat.' Science Translational Medicine 2016;8(366):366ra165.
- **ip status**: public-domain
- **sensors**: sensor-microfluidic-sweat-collection, sensor-sweat-rate, sensor-ph, sensor-lactate, sensor-electrolyte, sensor-glucose-cgm
- **algorithms**: algo-hydration-status, algo-electrolyte-trend
- **prior art notes**: Discloses a soft, skin-mounted microfluidic 'sticker' that wicks sweat from the skin into a network of microchannels and reservoirs, measures sweat rate and total sweat loss, and performs colorimetric assays (pH, chloride, lactate, glucose) read out by eye or smartphone camera. Any wearable claim reciting 'a skin-mounted patch with microfluidic channels collecting perspiration' combined with 'rate measurement' and/or 'colorimetric or electrochemical analysis of constituents' reads on Koh/Rogers 2016. Anchor for the patch × microfluidic-sweat-collection cross-cut on the real side; [[dune-stillsuit]] (1965) is the fictional antecedent.
